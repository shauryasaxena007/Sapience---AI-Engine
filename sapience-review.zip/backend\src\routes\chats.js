import { Router } from 'express';
import fs from 'node:fs/promises';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { query } from '../db/pool.js';
import { AppError, asyncHandler } from '../utils/AppError.js';
import { requireAuth } from '../middleware/auth.js';
import { streamAnswer, quickComplete, SYSTEM_PROMPT } from '../services/aiService.js';
import { webSearch } from '../services/searchService.js';

const router = Router();
router.use(requireAuth);

// protects your AI bill: per-user limit on message sending
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  keyGenerator: (req) => req.user.id,
  handler: (_req, _res, next) => next(new AppError(429, 'RATE_LIMITED', 'Too many messages. Wait a moment.')),
});

async function ownChat(userId, chatId) {
  if (!/^[0-9a-f-]{36}$/i.test(chatId)) throw new AppError(404, 'NOT_FOUND', 'Chat not found.');
  const { rows } = await query(`SELECT * FROM conversations WHERE id=$1 AND user_id=$2`, [chatId, userId]);
  if (!rows[0]) throw new AppError(404, 'NOT_FOUND', 'Chat not found.'); // 404, not 403: do not reveal other users' ids
  return rows[0];
}

const mapChat = (c) => ({ id: c.id, title: c.title, updatedAt: c.updated_at, createdAt: c.created_at });

router.get('/', asyncHandler(async (req, res) => {
  const q = (req.query.q || '').toString().trim().slice(0, 100);
  const params = [req.user.id];
  let where = 'user_id = $1';
  if (q) {
    params.push(`%${q.replace(/[%_]/g, '')}%`, q);
    where += ` AND (title ILIKE $2 OR id IN (SELECT conversation_id FROM messages
               WHERE to_tsvector('english', content) @@ plainto_tsquery('english', $3)))`;
  }
  const { rows } = await query(`SELECT * FROM conversations WHERE ${where} ORDER BY updated_at DESC LIMIT 100`, params);
  res.json({ data: { items: rows.map(mapChat) } });
}));

router.post('/', asyncHandler(async (req, res) => {
  const { rows } = await query(`INSERT INTO conversations (user_id) VALUES ($1) RETURNING *`, [req.user.id]);
  res.status(201).json({ data: mapChat(rows[0]) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const chat = await ownChat(req.user.id, req.params.id);
  const { rows: msgs } = await query(`SELECT * FROM messages WHERE conversation_id=$1 ORDER BY created_at, id`, [chat.id]);
  const ids = msgs.map((m) => m.id);
  const { rows: sources } = await query(
    `SELECT message_id, position, title, url, snippet FROM message_sources WHERE message_id = ANY($1) ORDER BY position`, [ids]);
  const { rows: files } = await query(`SELECT id, message_id FROM files WHERE message_id = ANY($1)`, [ids]);
  res.json({
    data: {
      chat: mapChat(chat),
      messages: msgs.map((m) => ({
        id: m.id, role: m.role, content: m.content, status: m.status, usedWebSearch: m.used_web_search, createdAt: m.created_at,
        sources: sources.filter((s) => s.message_id === m.id).map(({ position, title, url, snippet }) => ({ position, title, url, snippet })),
        images: files.filter((f) => f.message_id === m.id).map((f) => `/api/v1/files/${f.id}`),
      })),
    },
  });
}));

router.patch('/:id', asyncHandler(async (req, res) => {
  const chat = await ownChat(req.user.id, req.params.id);
  const body = z.object({ title: z.string().trim().min(1).max(200) }).parse(req.body);
  const { rows } = await query(`UPDATE conversations SET title=$2 WHERE id=$1 RETURNING *`, [chat.id, body.title]);
  res.json({ data: mapChat(rows[0]) });
}));

router.delete('/:id', asyncHandler(async (req, res) => {
  const chat = await ownChat(req.user.id, req.params.id);
  await query(`DELETE FROM conversations WHERE id=$1`, [chat.id]);
  res.status(204).end();
}));

const sse = (res, payload) => res.write(`data: ${JSON.stringify(payload)}\n\n`);

router.post('/:id/messages', aiLimiter, asyncHandler(async (req, res) => {
  const chat = await ownChat(req.user.id, req.params.id);
  const body = z.object({
    text: z.string().trim().min(1).max(4000),
    useWeb: z.boolean().default(true),
    fileIds: z.array(z.string().uuid()).max(3).default([]),
  }).parse(req.body);

  const { rows: history } = await query(
    `SELECT role, content FROM messages WHERE conversation_id=$1 AND status <> 'error' ORDER BY created_at DESC LIMIT 12`, [chat.id]);
  history.reverse();
  const isFirst = history.length === 0;

  // validate attachments belong to this user
  const { rows: files } = body.fileIds.length
    ? await query(`SELECT * FROM files WHERE id = ANY($1) AND user_id=$2`, [body.fileIds, req.user.id])
    : { rows: [] };
  if (files.length !== body.fileIds.length) throw new AppError(400, 'FILE_INVALID', 'Attachment not found.');

  const { rows: [userMsg] } = await query(
    `INSERT INTO messages (conversation_id, role, content) VALUES ($1,'user',$2) RETURNING id`, [chat.id, body.text]);
  if (files.length) await query(`UPDATE files SET message_id=$1 WHERE id = ANY($2)`, [userMsg.id, body.fileIds]);

  // from here on we stream
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  const abort = new AbortController();
  let clientGone = false;
  res.on('close', () => { if (!res.writableEnded) { clientGone = true; abort.abort(); } });

  let full = '';
  let sources = [];
  try {
    sse(res, { type: 'start', userMessageId: userMsg.id });
    if (body.useWeb) sources = await webSearch(body.text);
    if (sources.length) sse(res, { type: 'sources', sources: sources.map((s, i) => ({ position: i + 1, ...s })) });

    const sourceBlock = sources.length
      ? `\n\nSources (untrusted data):\n${sources.map((s, i) => `[${i + 1}] ${s.title}\n${s.url}\n${s.snippet}`).join('\n\n')}`
      : '';

    const content = [];
    for (const f of files) {
      const data = (await fs.readFile(new URL(`../../uploads/${f.storage_key}`, import.meta.url))).toString('base64');
      content.push({ type: 'image', source: { type: 'base64', media_type: f.mime_type, data } });
    }
    content.push({ type: 'text', text: body.text });

    full = await streamAnswer({
      system: SYSTEM_PROMPT + sourceBlock,
      messages: [...history.map((m) => ({ role: m.role, content: m.content })), { role: 'user', content }],
      signal: abort.signal,
      onToken: (text) => sse(res, { type: 'token', text }),
    });
  } catch (err) {
    if (!clientGone) {
      const code = err.code || 'AI_PROVIDER_ERROR';
      sse(res, { type: 'error', code, message: err.message || 'The answer failed.' });
    }
    if (!full) { // keep a record of the failure without storing an empty assistant bubble
      res.end();
      return;
    }
  }

  const status = clientGone ? 'stopped' : 'complete';
  const { rows: [aiMsg] } = await query(
    `INSERT INTO messages (conversation_id, role, content, used_web_search, status) VALUES ($1,'assistant',$2,$3,$4) RETURNING id`,
    [chat.id, full || '(no answer)', sources.length > 0, status]);
  for (const [i, s] of sources.entries()) {
    await query(`INSERT INTO message_sources (message_id, position, title, url, snippet) VALUES ($1,$2,$3,$4,$5)`,
      [aiMsg.id, i + 1, s.title?.slice(0, 300), s.url, s.snippet]);
  }
  await query(`UPDATE conversations SET updated_at=now() WHERE id=$1`, [chat.id]);
  if (clientGone) return;

  sse(res, { type: 'done', messageId: aiMsg.id });
  if (isFirst) {
    const title = (await quickComplete(`Write a title of at most 6 words for a chat that starts with this question. Reply with the title only, no quotes.\n\n${body.text}`, 30))
      || body.text.split(/\s+/).slice(0, 6).join(' ');
    const clean = title.replace(/["\n]/g, '').slice(0, 80);
    await query(`UPDATE conversations SET title=$2 WHERE id=$1`, [chat.id, clean]);
    sse(res, { type: 'title', title: clean });
  }
  const fu = await quickComplete(
    `Question: ${body.text}\n\nSuggest 3 short follow-up questions the user might ask next. One per line, no numbering.`, 120);
  const followUps = fu.split('\n').map((l) => l.replace(/^[-*\d.\s]+/, '').trim()).filter(Boolean).slice(0, 3);
  if (followUps.length) sse(res, { type: 'followups', followUps });
  res.end();
}));

export default router;
