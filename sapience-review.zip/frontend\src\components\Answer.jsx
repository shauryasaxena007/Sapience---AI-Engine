import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import Icon from './Icon.jsx';

function Cite({ n, sources }) {
  const s = sources.find((x) => x.position === Number(n));
  const chip = 'mx-0.5 inline-grid h-[1.15em] min-w-[1.15em] place-items-center rounded bg-mark/25 px-1 align-baseline font-sans text-[0.7em] font-bold text-ink no-underline';
  return s
    ? <a className={chip} href={s.url} target="_blank" rel="noreferrer" title={s.title}>{n}</a>
    : <span className={chip}>{n}</span>;
}

export default function Answer({ message, isStreaming, onSave, onFollowUp, followUps }) {
  const [copied, setCopied] = useState(false);
  const sources = message.sources || [];
  // turn [1] into a link we can render as a citation chip
  const text = message.content.replace(/\[(\d{1,2})\](?!\()/g, '[$1](#cite-$1)');

  const copy = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true); setTimeout(() => setCopied(false), 1500);
  };

  return (
    <article className="card p-5" aria-busy={isStreaming}>
      {isStreaming && !message.content && (
        <div className="space-y-2" aria-label="Thinking">
          <div className="skeleton h-4 w-3/4" /><div className="skeleton h-4 w-full" /><div className="skeleton h-4 w-2/3" />
        </div>
      )}
      <div className={`answer ${isStreaming && message.content ? 'cursor' : ''}`}>
        <ReactMarkdown
          components={{
            a: ({ href, children, ...p }) => href?.startsWith('#cite-')
              ? <Cite n={href.slice(6)} sources={sources} />
              : <a href={href} target="_blank" rel="noreferrer noopener" {...p}>{children}</a>,
          }}
        >{text}</ReactMarkdown>
      </div>

      {sources.length > 0 && (
        <section className="mt-4 border-t border-line pt-4" aria-label="Sources">
          <h3 className="mb-2 text-sm font-semibold text-mute">Sources</h3>
          <ol className="grid gap-2 sm:grid-cols-2">
            {sources.map((s) => (
              <li key={s.position}>
                <a href={s.url} target="_blank" rel="noreferrer" className="flex gap-2 rounded-lg border border-line p-2.5 text-sm hover:border-accent">
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded bg-mark/25 text-xs font-bold">{s.position}</span>
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{s.title}</span>
                    <span className="block truncate text-xs text-mute">{new URL(s.url).hostname.replace(/^www\./, '')}</span>
                  </span>
                </a>
              </li>
            ))}
          </ol>
        </section>
      )}

      {!isStreaming && message.id && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {/* onMouseDown preventDefault keeps the user's text selection alive when clicking the button */}
          <button className="btn-primary" onMouseDown={(e) => e.preventDefault()} onClick={() => onSave(message, window.getSelection()?.toString().trim())}>
            <Icon name="note" className="h-4 w-4" /> Save to OneNote
          </button>
          <button className="btn-ghost" onClick={copy}><Icon name={copied ? 'check' : 'copy'} className="h-4 w-4" /> {copied ? 'Copied' : 'Copy'}</button>
          {message.status === 'stopped' && <span className="text-xs text-mute">Stopped early</span>}
        </div>
      )}
      {followUps?.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {followUps.map((f) => (
            <button key={f} className="rounded-full border border-line px-3 py-1.5 text-sm hover:border-accent hover:text-accent" onClick={() => onFollowUp(f)}>{f}</button>
          ))}
        </div>
      )}
    </article>
  );
}
